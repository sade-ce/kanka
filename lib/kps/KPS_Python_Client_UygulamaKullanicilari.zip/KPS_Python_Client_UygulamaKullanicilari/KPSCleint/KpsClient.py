from KPSHelper import KPSRequestHelper

helper = KPSRequestHelper()

sorgulayanKimlikNo = ""
sorgulanacakKimliNo = ""

username = "test_user2"
password = "Twm=x5Gb"

kpsResult = helper.BilesikKisiSorgula(sorgulayanKimlikNo,sorgulanacakKimliNo,username,password)
