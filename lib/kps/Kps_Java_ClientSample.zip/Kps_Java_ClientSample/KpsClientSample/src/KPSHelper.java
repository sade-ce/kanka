import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.time.temporal.ChronoUnit;


public class KPSHelper {
	
	//Ger�ek Ortam
	static String stsUrl = "https://kpsv2.saglik.gov.tr/STS/STSService.svc";
	static String kpsServiceUrl= "https://kpsv2.saglik.gov.tr/Router/RoutingService.svc";
	
	//Test Ortam�
	static String stsTestUrl = "https://kpsv2test.saglik.gov.tr/STS/STSService.svc";
	static String kpsServiceTestUrl= "https://kpsv2test.saglik.gov.tr/Router/RoutingService.svc";
	
	
	
	public static void main(String [] args)
	{
		String username = "test_user";
		String password = "f6)@6U:l";
		
		String token = GetSTSToken(username,password);
		
		String sorgulanacakKimlikNo = "";
		String kpsResult = GetKpsRequestResult(token,sorgulanacakKimlikNo);
		
		//KpsServis xml sonucunu yaz
		System.out.println(kpsResult);
	}

	
	
	public static String GetKpsRequestResult(String token, String sorgulanacakKimlikNo){
	
		Instant created = Instant.now();
		Instant expires = created.plus(5,ChronoUnit.MINUTES);
		
		String kpsRequestEnvelope = "";
		kpsRequestEnvelope += "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:a=\"http://www.w3.org/2005/08/addressing\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">";
		kpsRequestEnvelope += "<s:Header>";
		kpsRequestEnvelope += "<a:Action s:mustUnderstand=\"1\">https://www.saglik.gov.tr/KPS/01/01/2017/IKpsServices/BilesikKisiSorgula</a:Action>";
		kpsRequestEnvelope += "<a:MessageID>urn:uuid:" + java.util.UUID.randomUUID().toString() + "</a:MessageID>";
		kpsRequestEnvelope += "<a:ReplyTo>";
		kpsRequestEnvelope += "<a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>";
		kpsRequestEnvelope += "</a:ReplyTo>";
		kpsRequestEnvelope += "<a:To s:mustUnderstand=\"1\">"+kpsServiceUrl+"</a:To>";
		kpsRequestEnvelope += "<o:Security s:mustUnderstand=\"1\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">";
		kpsRequestEnvelope += "<u:Timestamp u:Id=\"_0\">";
		kpsRequestEnvelope += "<u:Created>" + created.toString() + "</u:Created>";
		kpsRequestEnvelope += "<u:Expires>" + expires.toString() + "</u:Expires>";
		kpsRequestEnvelope += "</u:Timestamp>";

		kpsRequestEnvelope += token;

		kpsRequestEnvelope += "</o:Security>";
		kpsRequestEnvelope += "</s:Header>";
		kpsRequestEnvelope += "<s:Body>";
		kpsRequestEnvelope += "<BilesikKisiSorgula xmlns=\"https://www.saglik.gov.tr/KPS/01/01/2017\">";
		kpsRequestEnvelope += "<kimlikNo>"+sorgulanacakKimlikNo+"</kimlikNo>";
		kpsRequestEnvelope += "</BilesikKisiSorgula>";
		kpsRequestEnvelope += "</s:Body>";
		kpsRequestEnvelope += "</s:Envelope>";
        
		System.out.println("KpsServis iste�i g�nderiliyor.....");
        String result = SendRequest(kpsServiceTestUrl, kpsRequestEnvelope);
        System.out.println("KpsServis iste�i ba�ar�l�");
        
        
		return result;
	}
	
	
	
	public static String GetSTSToken(String username,String password){
		
		String tokenEnvelope = "";
		String kurumKodu = "123456";
        String uygulamaKodu = "8353df93-453c-4e23-8be8-2f913dd35313";
		
		
		Instant created = Instant.now();
		Instant expires = created.plus(5,ChronoUnit.MINUTES);
		
		tokenEnvelope += "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:a=\"http://www.w3.org/2005/08/addressing\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">";
		tokenEnvelope += "<s:Header>";
		tokenEnvelope += "<a:Action s:mustUnderstand=\"1\">http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue</a:Action>";
		tokenEnvelope += "<a:MessageID>urn:uuid:" + java.util.UUID.randomUUID().toString() + "</a:MessageID>";
		tokenEnvelope += "<a:ReplyTo>";
		tokenEnvelope += "<a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>";
		tokenEnvelope += "</a:ReplyTo>";
		tokenEnvelope += "<a:To s:mustUnderstand=\"1\">"+stsTestUrl+"</a:To>";
		
		tokenEnvelope += "<KurumKodu a:IsReferenceParameter=\"true\" xmlns=\"\">" + kurumKodu + "</KurumKodu>";
		tokenEnvelope += "<UygulamaKodu a:IsReferenceParameter=\"true\" xmlns=\"\">" + uygulamaKodu + "</UygulamaKodu>";
		
		
		tokenEnvelope += "<o:Security s:mustUnderstand=\"1\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">";
		tokenEnvelope += "<u:Timestamp u:Id=\"_0\">";
		tokenEnvelope += "<u:Created>" + created.toString() + "</u:Created>";
		tokenEnvelope += "<u:Expires>" + expires.toString() + "</u:Expires>";
		tokenEnvelope += "</u:Timestamp>";
		tokenEnvelope += "<o:UsernameToken u:Id=\"uuid-" + java.util.UUID.randomUUID().toString() + "-1\">";
		tokenEnvelope += "<o:Username>" + username + "</o:Username>";
		tokenEnvelope += "<o:Password>" + password + "</o:Password>";
		tokenEnvelope += "</o:UsernameToken>";
		tokenEnvelope += "</o:Security>";
		tokenEnvelope += "</s:Header>";
		tokenEnvelope += "<s:Body>";
		tokenEnvelope += "<trust:RequestSecurityToken xmlns:trust=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512\">";
		tokenEnvelope += "<wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\">";
		tokenEnvelope += "<a:EndpointReference>";
		tokenEnvelope += "<a:Address>"+kpsServiceTestUrl+"</a:Address>";
		tokenEnvelope += "</a:EndpointReference>";
		tokenEnvelope += "</wsp:AppliesTo>";
		tokenEnvelope += "<trust:KeyType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Bearer</trust:KeyType>";
		tokenEnvelope += "<trust:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</trust:RequestType>";
		tokenEnvelope += "</trust:RequestSecurityToken>";
		tokenEnvelope += "</s:Body>";
		tokenEnvelope += "</s:Envelope>";
		
		System.out.println("Token alma iste�i g�nderiliyor....");
		String tokenResult = SendRequest(stsTestUrl, tokenEnvelope);

		System.out.println("Token alma ba�ar�l�");
		
		//gelen cevap i�inden token'� al�yoruz
		String token= tokenResult.substring(tokenResult.indexOf("<saml:Assertion"),tokenResult.indexOf("</trust:RequestedSecurityToken>"));

		//token'� d�nderiyoruz
		return token;		
	}
	
	
	
	public  static String SendRequest(String targetUrl, String envelope){
		
		try {
			
			URL url = new URL(targetUrl);
			
			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
		    connection.setRequestMethod("POST");
		    connection.setRequestProperty("Content-Type", "application/soap+xml; charset=UTF-8");
		    connection.setRequestProperty("Content-Length", Integer.toString(envelope.getBytes().length));
		    connection.setUseCaches(false);
		    connection.setDoOutput(true);
		    DataOutputStream wr = new DataOutputStream (connection.getOutputStream());
		    wr.writeBytes(envelope);
		    wr.close();


		    InputStream is = connection.getInputStream();
		    BufferedReader rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		    StringBuilder response = new StringBuilder();
		    String line;
		    while ((line = rd.readLine()) != null) {
		      response.append(line);
		      response.append('\r');
		    }
		    rd.close();
		    
		    String r = response.toString();
		    //System.out.println(r);
		    return r;
		    
		    
		} catch (Exception e) {
			return "";
		}
		
		
		
		
	}
	
	
}
