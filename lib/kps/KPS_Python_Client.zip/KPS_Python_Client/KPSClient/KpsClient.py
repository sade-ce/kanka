from KPSHelper import KPSRequestHelper

helper = KPSRequestHelper()

sorgulanacakKimliNo = ""

username = "test_user"
password = "f6)@6U:l"

kpsResult = helper.BilesikKisiSorgula(sorgulanacakKimliNo,username,password)
