import uuid
import datetime
import requests
import urllib3
import xml.etree.ElementTree as ET
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class KPSRequestHelper:
    #Gerçek Ortam
    stsUrl = "https://kpsv2.saglik.gov.tr/STS/STSService.svc"
    kpsUrl = "https://kpsv2.saglik.gov.tr/Router/RoutingService.svc"

    #Test Ortamı
    stsTestUrl = "https://kpsv2test.saglik.gov.tr/STS/STSService.svc"
    kpsTestUrl = "https://kpsv2test.saglik.gov.tr/Router/RoutingService.svc"

    def BilesikKisiSorgula(self, sorgulanacakKimliNo,username,password):

        token = self.GetSTSToken(username,password)

        created = datetime.datetime.utcnow()
        created = created + datetime.timedelta(minutes=-1)
        expires = created + datetime.timedelta(minutes=5)

        kpsRequest = ""
        kpsRequest += "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:a=\"http://www.w3.org/2005/08/addressing\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"
        kpsRequest += "<s:Header>"
        kpsRequest += "<a:Action s:mustUnderstand=\"1\">https://www.saglik.gov.tr/KPS/01/01/2017/IKpsServices/BilesikKisiSorgula</a:Action>"
        kpsRequest += "<a:MessageID>urn:uuid:%s</a:MessageID>" % uuid.uuid4()
        kpsRequest += "<a:ReplyTo>"
        kpsRequest += "<a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>"
        kpsRequest += "</a:ReplyTo>"
        kpsRequest += "<a:To s:mustUnderstand=\"1\">%s</a:To>" % self.kpsTestUrl
        kpsRequest += "<o:Security s:mustUnderstand=\"1\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"
        kpsRequest += "<u:Timestamp u:Id=\"_0\">"
        kpsRequest += "<u:Created>%s</u:Created>" % created.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        kpsRequest += "<u:Expires>%s</u:Expires>" % expires.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        kpsRequest += "</u:Timestamp>"

        kpsRequest += token

        kpsRequest += "</o:Security>"
        kpsRequest += "</s:Header>"
        kpsRequest += "<s:Body>"
        kpsRequest += "<BilesikKisiSorgula xmlns=\"https://www.saglik.gov.tr/KPS/01/01/2017\">"
        kpsRequest += "<kimlikNo>%s</kimlikNo>"%sorgulanacakKimliNo
        kpsRequest += "</BilesikKisiSorgula>"
        kpsRequest += "</s:Body>"
        kpsRequest += "</s:Envelope>"

        result = self.SendSoapRequest(self.kpsTestUrl,kpsRequest)
        print(result)



    def GetSTSToken(self,username,password):

        kurumKodu = "123456"
        uygulamaKodu = "8353df93-453c-4e23-8be8-2f913dd35313"
        created = datetime.datetime.utcnow()
        expires = created + datetime.timedelta(minutes=5)

        tokenRequest = ""

        tokenRequest += "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:a=\"http://www.w3.org/2005/08/addressing\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"
        tokenRequest += "<s:Header>"
        tokenRequest += "<a:Action s:mustUnderstand=\"1\">http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue</a:Action>"
        tokenRequest += "<a:MessageID>urn:uuid:%s</a:MessageID>" % uuid.uuid4()
        tokenRequest += "<a:ReplyTo>"
        tokenRequest += "<a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>"
        tokenRequest += "</a:ReplyTo>"
        tokenRequest += "<a:To s:mustUnderstand=\"1\">%s</a:To>" % self.stsTestUrl

        tokenRequest += "<KurumKodu a:IsReferenceParameter=\"true\" xmlns=\"\">%s</KurumKodu>" % kurumKodu
        tokenRequest += "<UygulamaKodu a:IsReferenceParameter=\"true\" xmlns=\"\">%s</UygulamaKodu>" % uygulamaKodu


        tokenRequest += "<o:Security s:mustUnderstand=\"1\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"
        tokenRequest += "<u:Timestamp u:Id=\"_0\">"
        tokenRequest += "<u:Created>%s</u:Created>" % created.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        tokenRequest += "<u:Expires>%s</u:Expires>" % expires.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        tokenRequest += "</u:Timestamp>"
        tokenRequest += "<o:UsernameToken u:Id=\"uuid-%s-1\">" % uuid.uuid4()
        tokenRequest += "<o:Username>%s</o:Username>" % username
        tokenRequest += "<o:Password>%s</o:Password>" % password
        tokenRequest += "</o:UsernameToken>"
        tokenRequest += "</o:Security>"
        tokenRequest += "</s:Header>"

        tokenRequest += "<s:Body>"
        tokenRequest += "<trust:RequestSecurityToken xmlns:trust=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512\">"
        tokenRequest += "<wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\">"
        tokenRequest += "<a:EndpointReference>"
        tokenRequest += "<a:Address>%s</a:Address>" % self.kpsTestUrl
        tokenRequest += "</a:EndpointReference>"
        tokenRequest += "</wsp:AppliesTo>"
        tokenRequest += "<trust:KeyType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Bearer</trust:KeyType>"
        tokenRequest += "<trust:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</trust:RequestType>"
        tokenRequest += "</trust:RequestSecurityToken>"
        tokenRequest += "</s:Body>"
        tokenRequest += "</s:Envelope>"

        response = self.SendSoapRequest(self.stsTestUrl,tokenRequest)

        nsmap = {'s': 'http://www.w3.org/2003/05/soap-envelope',
                 'trust': 'http://docs.oasis-open.org/ws-sx/ws-trust/200512',
                 'saml': 'urn:oasis:names:tc:SAML:1.0:assertion'}

        ET.register_namespace('s', "ttp://www.w3.org/2003/05/soap-envelope")
        ET.register_namespace('trust', "http://docs.oasis-open.org/ws-sx/ws-trust/200512")
        ET.register_namespace('saml', "urn:oasis:names:tc:SAML:1.0:assertion")
        ET.register_namespace('wsp', "http://schemas.xmlsoap.org/ws/2004/09/policy")
        ET.register_namespace('', "http://www.w3.org/2000/09/xmldsig#")

        doc = ET.fromstring(response)


        token = doc.find('s:Body',namespaces=nsmap).find('trust:RequestSecurityTokenResponseCollection',namespaces=nsmap).find('trust:RequestSecurityTokenResponse',namespaces=nsmap).find('trust:RequestedSecurityToken',namespaces=nsmap).find('saml:Assertion',namespaces=nsmap)

        tokenString = ET.tostring(token).decode("UTF-8")
        return tokenString



    #soap isteği
    def SendSoapRequest(self, targetUrl, envelopeString):
        encoded_request = envelopeString.encode('utf-8')
        headers = {
            "Content-Type": "application/soap+xml; charset=UTF-8",
            "Content-Length": str(len(encoded_request))
        }

        response = requests.post(url=targetUrl,
                                 headers=headers,
                                 data=encoded_request,
                                 verify=False)

        result = str(response.content,'utf-8')

        return result