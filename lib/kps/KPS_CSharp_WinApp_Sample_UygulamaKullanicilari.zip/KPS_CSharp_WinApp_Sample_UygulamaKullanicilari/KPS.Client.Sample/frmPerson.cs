﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KPS.Client.Sample
{
    public partial class frmPerson : Form
    {
        public frmPerson()
        {
            InitializeComponent();
        }


        Helper.AuthController auth = new Helper.AuthController();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSorgula_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKimlikNo.Text))
            {
                MessageBox.Show("Lütfen kimlik numarası giriniz.");
                return;
            }

            try
            {
                long? sorgulayanKimlikNo = null;

                using (Helper.ServiceApiFactory api = new Helper.ServiceApiFactory(auth.GetToken("test_user2", "Twm=x5Gb", sorgulayanKimlikNo)))// test ortamı username,password
                {
                    KpsServiceClient.IKpsServices kpsServices = api.GetService<KpsServiceClient.IKpsServices>("WS2007FederationHttpBinding_IKpsServices");
                    long tc = Convert.ToInt64(txtKimlikNo.Text);

                    #region HeaderaAciklamaEkle

                    //
                    //
                    // Sorgu yaparken gönderdiğiniz requestin header alanına 
                    // açıklama ekleyip göndermek isterseniz sorgulamayı aşağıdaki using
                    // bloğu içinde yapınız. 
                    //
                    //

                    //using (OperationContextScope scope = new OperationContextScope((IContextChannel)kpsServices))
                    //{
                    //    string aciklama = "Deneme Açıklama";
                    //    MessageHeader<string> header = new MessageHeader<string>(aciklama);
                    //    var untyped = header.GetUntypedHeader("Aciklama", "");
                    //    OperationContext.Current.OutgoingMessageHeaders.Add(untyped);

                    //    // Sorgulama burada yapılırsa Header içerisinde açıklama alanı gönderilir.
                    //    var result = kpsServices.BilesikKisiSorgula(tc);
                    //}

                    #endregion

                    var resultPerson = kpsServices.BilesikKisiSorgula(tc);

                    if (resultPerson.HataBilgisi != null)
                    {
                        MessageBox.Show(resultPerson.HataBilgisi.Aciklama);
                        return;
                    }

                    //mavi kartlı kişi bilgileri
                    if (resultPerson.Sonuc.MaviKartliKisiKutukleri != null)
                    {
                        lblAdi.Text = resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad;
                        lblSoyadi.Text = resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                        lblBabaAdi.Text = resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.BabaAd;
                        lblAnneAdi.Text = resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.AnneAd;
                        lblDogumYeri.Text = resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumYer;
                        lblDogumTarihi.Text = new DateTime(
                            resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Yil.Value,
                            resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Ay.Value,
                            resultPerson.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Gun.Value
                            ).ToShortDateString();

                        lblKimlikTuru.Text = "MAVİ KART";
                    }
                    //vatandaş kişi bilgileri
                    else if (resultPerson.Sonuc.TCVatandasiKisiKutukleri != null)
                    {
                        lblAdi.Text = resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad;
                        lblSoyadi.Text = resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                        lblBabaAdi.Text = resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.BabaAd;
                        lblAnneAdi.Text = resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.AnneAd;
                        lblDogumYeri.Text = resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumYer;
                        lblDogumTarihi.Text = new DateTime(
                            resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Yil.Value,
                            resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Ay.Value,
                            resultPerson.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Gun.Value
                            ).ToShortDateString();

                        lblKimlikTuru.Text = "TC VATANDAŞ";

                    }
                    //yabancı kişi bilgileri
                    else if (resultPerson.Sonuc.YabanciKisiKutukleri != null)
                    {
                        lblAdi.Text = resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad;
                        lblSoyadi.Text = resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                        lblBabaAdi.Text = resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.BabaAd;
                        lblAnneAdi.Text = resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.AnneAd;
                        lblDogumYeri.Text = resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumYer;

                        if (resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih != null)
                        {
                            lblDogumTarihi.Text = new DateTime(
                            resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Yil.Value,
                            resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Ay.Value,
                            resultPerson.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Gun.Value
                            ).ToShortDateString();
                        }


                        lblKimlikTuru.Text = "YABANCI";
                    }
                    else
                    {
                        MessageBox.Show("Kayıt bulunamadı.");
                    }
                }
            }
            catch (FaultException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
