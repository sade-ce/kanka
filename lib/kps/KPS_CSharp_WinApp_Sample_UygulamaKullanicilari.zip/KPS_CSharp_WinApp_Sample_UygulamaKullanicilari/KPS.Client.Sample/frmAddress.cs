﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KPS.Client.Sample
{
    public partial class frmAddress : Form
    {
        public frmAddress()
        {
            InitializeComponent();
        }

        Helper.AuthController auth = new Helper.AuthController();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSorgula_Click(object sender, EventArgs e)
        {
            Clear();

            if (string.IsNullOrWhiteSpace(txtKimlikNo.Text))
            {
                MessageBox.Show("Lütfen kimlik numarası giriniz.");
                return;
            }
            
            try
            {
                long? sorgulayanKimlikNo = null;

                using (Helper.ServiceApiFactory api = new Helper.ServiceApiFactory(auth.GetToken("test_user2", "Twm=x5Gb", sorgulayanKimlikNo))) // test username, test password
                {
                    KpsServiceClient.IKpsServices kpsServices = api.GetService<KpsServiceClient.IKpsServices>("WS2007FederationHttpBinding_IKpsServices");
                    long tc = Convert.ToInt64(txtKimlikNo.Text);

                    #region HeaderaAciklamaEkle

                    //
                    //
                    // Sorgu yaparken gönderdiğiniz requestin header alanına 
                    // açıklama ekleyip göndermek isterseniz sorgulamayı aşağıdaki using
                    // bloğu içinde yapınız. 
                    //
                    //

                    //using (OperationContextScope scope = new OperationContextScope((IContextChannel)kpsServices))
                    //{
                    //    string aciklama = "Deneme Açıklama";
                    //    MessageHeader<string> header = new MessageHeader<string>(aciklama);
                    //    var untyped = header.GetUntypedHeader("Aciklama", "");
                    //    OperationContext.Current.OutgoingMessageHeaders.Add(untyped);

                    //    // Sorgulama burada yapılırsa Header içerisinde açıklama alanı gönderilir.
                    //    var result = kpsServices.BilesikKisiveAdresSorgula(tc);
                    //}

                    #endregion

                    // hem adres hemde kişi bilgilerini sorgula
                    var resultPersonAndAddress = kpsServices.BilesikKisiveAdresSorgula(tc);

                    if (resultPersonAndAddress.Sonuc.TCVatandasiKisiKutukleri != null)
                    {
                        lblAdiSoyadi.Text = resultPersonAndAddress.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad + " " + resultPersonAndAddress.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                    }
                    else if (resultPersonAndAddress.Sonuc.MaviKartliKisiKutukleri != null)
                    {
                        lblAdiSoyadi.Text = resultPersonAndAddress.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad + " " + resultPersonAndAddress.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                    }
                    else if (resultPersonAndAddress.Sonuc.YabanciKisiKutukleri != null)
                    {
                        lblAdiSoyadi.Text = resultPersonAndAddress.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad + " " + resultPersonAndAddress.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                    }

                    //sadece adres bilgilerini sorgula
                    var resultOnlyAddress = kpsServices.KimlikNoIleAdresBilgisiSorgula(tc);

                    if (resultOnlyAddress.HataBilgisi != null)
                    {
                        MessageBox.Show(resultOnlyAddress.HataBilgisi.Aciklama);
                        return;
                    }

                    if (resultOnlyAddress.Sonuc != null && resultOnlyAddress.Sonuc.HataBilgisi == null)
                    {
                        lblAcikAdres.Text = resultOnlyAddress.Sonuc.AcikAdres;
                        lblAdresNo.Text = resultOnlyAddress.Sonuc.AdresNo.ToString();

                        if (resultOnlyAddress.Sonuc.IlIlceMerkezAdresi != null)
                        {
                            lblIl.Text = resultOnlyAddress.Sonuc.IlIlceMerkezAdresi.Il;
                            lblIlce.Text = resultOnlyAddress.Sonuc.IlIlceMerkezAdresi.Ilce;
                            lblMahalleKoy.Text = resultOnlyAddress.Sonuc.IlIlceMerkezAdresi.Mahalle;

                        }
                        else if (resultOnlyAddress.Sonuc.KoyAdresi != null)
                        {
                            lblIl.Text = resultOnlyAddress.Sonuc.KoyAdresi.Il;
                            lblIlce.Text = resultOnlyAddress.Sonuc.KoyAdresi.Ilce;
                            lblMahalleKoy.Text = resultOnlyAddress.Sonuc.KoyAdresi.Koy;
                        }
                        else if (resultOnlyAddress.Sonuc.YurtDisiAdresi != null)
                        {
                            lblUlke.Text = resultOnlyAddress.Sonuc.YurtDisiAdresi.YabanciUlke.Aciklama;
                            lblIl.Text = resultOnlyAddress.Sonuc.YurtDisiAdresi.YabanciSehir;
                            lblAcikAdres.Text = resultOnlyAddress.Sonuc.YurtDisiAdresi.YabanciAdres;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Kayıt bulunamadı.");
                    }

                }
            }
            catch (FaultException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void Clear()
        {
            lblUlke.Text = "(yok)";
            lblAcikAdres.Text = "(yok)";
            lblAdiSoyadi.Text = "(yok)";
            lblAdresNo.Text = "(yok)";
            lblIl.Text = "(yok)";
            lblIlce.Text = "(yok)";
            lblMahalleKoy.Text = "(yok)";
            lblUlke.Text = "(yok)";

        }





    }
}
