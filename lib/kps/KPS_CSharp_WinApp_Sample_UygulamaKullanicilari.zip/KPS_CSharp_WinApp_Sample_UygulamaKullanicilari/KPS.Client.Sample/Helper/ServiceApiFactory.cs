﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.ServiceModel;

namespace KPS.Client.Sample.Helper
{
    public class ServiceApiFactory : IDisposable
    {
        private readonly List<ICommunicationObject> _activeServiceList;
        private readonly SecurityToken _authToken;

        public ServiceApiFactory(SecurityToken token)
        {
            _activeServiceList = new List<ICommunicationObject>();
            _authToken = token;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="endpointConfigurationName"></param>
        /// <returns></returns>
        public T GetService<T>(string endpointConfigurationName)
        {
            var factory = new ChannelFactory<T>(endpointConfigurationName, new EndpointAddress(KpsConfiguration.Instance.EndPoint));
            _activeServiceList.Add(factory);

            return factory.CreateChannelWithIssuedToken(_authToken);
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            foreach (var service in _activeServiceList)
            {
                try
                {
                    service.Close();
                }
                catch (CommunicationObjectFaultedException)
                {
                    service.Abort();
                }
                catch (TimeoutException)
                {
                    service.Abort();
                }
            }
        }

    }
}
