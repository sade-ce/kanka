﻿namespace KPS.Client.Sample.Helper
{
    public class KpsConfiguration
    {
        private KpsConfiguration() { }

        private static KpsConfiguration instance;


        public static KpsConfiguration Instance
        {
            get
            {
                if (instance == null)
                    instance = new KpsConfiguration()
                    {
                        EndPoint = "https://kpsv2test.saglik.gov.tr/Router/RoutingService.svc"
                    };

                return instance;
            }
        }
        

        public string EndPoint { get; set; }

    }
}
