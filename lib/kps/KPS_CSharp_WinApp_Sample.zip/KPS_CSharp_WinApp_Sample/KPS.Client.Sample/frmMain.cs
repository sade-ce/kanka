﻿using System;
using System.Windows.Forms;

namespace KPS.Client.Sample
{

    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

                

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnKisiSorgula_Click(object sender, EventArgs e)
        {
            frmPerson frm = new frmPerson();
            frm.ShowDialog();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddress_Click(object sender, EventArgs e)
        {
            frmAddress frm = new frmAddress();
            frm.ShowDialog();
        }

        
    }
}
