﻿using System;
using System.ServiceModel;
using System.Windows.Forms;

namespace KPS.Client.Sample
{
    public partial class frmPerson : Form
    {
        public frmPerson()
        {
            InitializeComponent();
        }


        Helper.AuthController auth = new Helper.AuthController();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSorgula_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKimlikNo.Text))
            {
                MessageBox.Show("Lütfen kimlik numarası giriniz.");
                return;
            }

            try
            {
                using (Helper.ServiceApiFactory api = new Helper.ServiceApiFactory(auth.GetToken("test_user", "f6)@6U:l")))// test ortamı username,password
                {
                    KpsServiceClient.IKpsServices kpsServices = api.GetService<KpsServiceClient.IKpsServices>("WS2007FederationHttpBinding_IKpsServices");
                    long tc = Convert.ToInt64(txtKimlikNo.Text);

                    #region HeaderaAciklamaEkle

                    //
                    //
                    // Sorgu yaparken gönderdiğiniz requestin header alanına 
                    // açıklama ekleyip göndermek isterseniz sorgulamayı aşağıdaki using
                    // bloğu içinde yapınız. 
                    //
                    //

                    //using (OperationContextScope scope = new OperationContextScope((IContextChannel)kpsServices))
                    //{
                    //    string aciklama = "Deneme Açıklama";
                    //    MessageHeader<string> header = new MessageHeader<string>(aciklama);
                    //    var untyped = header.GetUntypedHeader("Aciklama", "");
                    //    OperationContext.Current.OutgoingMessageHeaders.Add(untyped);

                    //    // Sorgulama burada yapılırsa Header içerisinde açıklama alanı gönderilir.
                    //    var result = kpsServices.BilesikKisiSorgula(tc);
                    //}

                    #endregion

                    var resultKisi = kpsServices.BilesikKisiSorgula(tc);
                    if (resultKisi.HataBilgisi != null)
                    {
                        MessageBox.Show(resultKisi.HataBilgisi.Aciklama);
                        return;
                    }

                    //mavi kartlı kişi bilgileri
                    if (resultKisi.Sonuc.MaviKartliKisiKutukleri != null)
                    {
                        lblAdi.Text = resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad;
                        lblSoyadi.Text = resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                        lblBabaAdi.Text = resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.BabaAd;
                        lblAnneAdi.Text = resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.AnneAd;
                        lblDogumYeri.Text = resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumYer;
                        lblDogumTarihi.Text = new DateTime(
                            resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Yil.Value,
                            resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Ay.Value,
                            resultKisi.Sonuc.MaviKartliKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Gun.Value
                            ).ToShortDateString();

                        lblKimlikTuru.Text = "MAVİ KART";
                    }
                    //vatandaş kişi bilgileri
                    else if (resultKisi.Sonuc.TCVatandasiKisiKutukleri != null)
                    {
                        lblAdi.Text = resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad;
                        lblSoyadi.Text = resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                        lblBabaAdi.Text = resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.BabaAd;
                        lblAnneAdi.Text = resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.AnneAd;
                        lblDogumYeri.Text = resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumYer;
                        lblDogumTarihi.Text = new DateTime(
                            resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Yil.Value,
                            resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Ay.Value,
                            resultKisi.Sonuc.TCVatandasiKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Gun.Value
                            ).ToShortDateString();

                        lblKimlikTuru.Text = "TC VATANDAŞ";

                    }
                    //yabancı kişi bilgileri
                    else if (resultKisi.Sonuc.YabanciKisiKutukleri != null)
                    {
                        lblAdi.Text = resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.Ad;
                        lblSoyadi.Text = resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.Soyad;
                        lblBabaAdi.Text = resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.BabaAd;
                        lblAnneAdi.Text = resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.AnneAd;
                        lblDogumYeri.Text = resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumYer;

                        if (resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih != null)
                        {
                            lblDogumTarihi.Text = new DateTime(
                            resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Yil.Value,
                            resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Ay.Value,
                            resultKisi.Sonuc.YabanciKisiKutukleri.KisiBilgisi.TemelBilgisi.DogumTarih.Gun.Value
                            ).ToShortDateString();
                        }


                        lblKimlikTuru.Text = "YABANCI";
                    }
                    else
                    {
                        MessageBox.Show("Kayıt bulunamadı.");
                    }




                }
            }
            catch (FaultException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
