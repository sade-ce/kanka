﻿using System;
using System.IdentityModel.Protocols.WSTrust;
using System.IdentityModel.Tokens;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;

namespace KPS.Client.Sample.Helper
{
    public class AuthController
    {
        private SecurityToken _token;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public SecurityToken GetToken(string userName, string password)
        {
            if (_token == null || _token.ValidTo <= DateTime.Now.ToUniversalTime())
            {
                CreateToken(userName, password);
            }

            return _token;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        private void CreateToken(string userName, string password)
        {
            ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);

            var rst = new RequestSecurityToken(RequestTypes.Issue);
            rst.AppliesTo = new EndpointReference(KpsConfiguration.Instance.EndPoint);
            rst.KeyType = KeyTypes.Bearer;


            using (var trustChannelFactory = new WSTrustChannelFactory("WS2007HttpBinding_IWSTrust13Sync"))
            {
                trustChannelFactory.Credentials.UserName.UserName = userName;
                trustChannelFactory.Credentials.UserName.Password = password;
                trustChannelFactory.TrustVersion = TrustVersion.WSTrust13;

                // uygulama kodu ve kurum kodu header.

                var adressBuilder = new EndpointAddressBuilder(trustChannelFactory.Endpoint.Address);
                
                adressBuilder.Headers.Add(AddressHeader.CreateAddressHeader("KurumKodu", string.Empty, KpsConfiguration.Instance.KurumKodu));
                adressBuilder.Headers.Add(AddressHeader.CreateAddressHeader("UygulamaKodu", string.Empty, KpsConfiguration.Instance.UygulamaKodu));

                

                trustChannelFactory.Endpoint.Address = adressBuilder.ToEndpointAddress();

                var channel = (WSTrustChannel)trustChannelFactory.CreateChannel();

                try
                {
                    _token = channel.Issue(rst);
                }
                catch (MessageSecurityException ex)
                {
                    channel.Abort();
                    throw new SecurityTokenException(ex.InnerException.Message, ex);
                }
                catch (FaultException ex)
                {
                    channel.Abort();
                    throw new FaultException(ex.Message);
                }
                catch (Exception ex)
                {
                    channel.Abort();
                    throw ex;
                }
            }
        }

    }

}


