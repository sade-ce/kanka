﻿namespace KPS.Client.Sample.Helper
{
    public class KpsConfiguration
    {
        private KpsConfiguration() { }

        private static KpsConfiguration instance;


        public static KpsConfiguration Instance
        {
            get
            {
                if (instance == null)
                    instance = new KpsConfiguration()
                    {
                        KurumKodu = 123456,//test kurum kodu
                        UygulamaKodu = "8353df93-453c-4e23-8be8-2f913dd35313", //test uygulama kodu
                        EndPoint = "https://kpsv2test.saglik.gov.tr/Router/RoutingService.svc"
                    };

                return instance;
            }
        }
        

        public long KurumKodu { get; set; }

        public string UygulamaKodu { get; set; }

        public string EndPoint { get; set; }

    }
}
