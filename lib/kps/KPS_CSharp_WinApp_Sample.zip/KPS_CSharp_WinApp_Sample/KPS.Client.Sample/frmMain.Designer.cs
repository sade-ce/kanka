﻿namespace KPS.Client.Sample
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnKisiSorgula = new System.Windows.Forms.Button();
            this.btnAddress = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnKisiSorgula
            // 
            this.btnKisiSorgula.Location = new System.Drawing.Point(26, 12);
            this.btnKisiSorgula.Name = "btnKisiSorgula";
            this.btnKisiSorgula.Size = new System.Drawing.Size(120, 52);
            this.btnKisiSorgula.TabIndex = 1;
            this.btnKisiSorgula.Text = "KİŞİ SORGULAMA";
            this.btnKisiSorgula.UseVisualStyleBackColor = true;
            this.btnKisiSorgula.Click += new System.EventHandler(this.btnKisiSorgula_Click);
            // 
            // btnAddress
            // 
            this.btnAddress.Location = new System.Drawing.Point(152, 12);
            this.btnAddress.Name = "btnAddress";
            this.btnAddress.Size = new System.Drawing.Size(120, 52);
            this.btnAddress.TabIndex = 2;
            this.btnAddress.Text = "ADRES SORGULAMA";
            this.btnAddress.UseVisualStyleBackColor = true;
            this.btnAddress.Click += new System.EventHandler(this.btnAddress_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 81);
            this.Controls.Add(this.btnAddress);
            this.Controls.Add(this.btnKisiSorgula);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sağlık Bakanlığı Kimlik Paylaşım Sistemi";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnKisiSorgula;
        private System.Windows.Forms.Button btnAddress;
    }
}