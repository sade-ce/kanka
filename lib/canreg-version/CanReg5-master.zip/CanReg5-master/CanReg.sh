#!/bin/sh
java -jar CanReg.jar
